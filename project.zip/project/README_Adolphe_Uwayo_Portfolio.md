
# 💼 Adolphe Uwayo – IT Professional Portfolio

Welcome to my personal portfolio!  
This project showcases my skills, projects, and experience as an IT student and software developer. Built using **React**, **TypeScript**, **Tailwind CSS**, and **Lucide React icons**, it’s designed to be fast, responsive, and production-ready.

---

## ✨ Features

- ✅ **Responsive Design** – Looks great on mobile, tablet, and desktop.
- 🧠 **Project Showcase** – Highlights key and recent projects with live demos and source code.
- 🧰 **Skills Overview** – Displays my tech stack and tools.
- 📄 **Resume Download/Preview** – Easily access my latest CV.
- 📬 **Contact Form** – Direct email integration for inquiries.
- 🔗 **Social Links** – Connect with me on GitHub, LinkedIn, and X (Twitter).

---

## 🚀 Getting Started

### Prerequisites

- [Node.js](https://nodejs.org/) (v18 or higher recommended)
- [npm](https://www.npmjs.com/) or [Yarn](https://yarnpkg.com/)

### Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/Adol1329/your-portfolio-repo.git
   cd your-portfolio-repo
   ```

2. **Install dependencies**
   ```bash
   npm install
   # or
   yarn install
   ```

3. **Start the development server**
   ```bash
   npm run dev
   # or
   yarn dev
   ```

4. **Open in your browser**
   Visit: [http://localhost:5173](http://localhost:5173)

### Build for Production

```bash
npm run build
# or
yarn build
```

The final production files will be located in the `dist/` directory.

---

## 📄 Resume (CV)

To enable the resume download or preview feature, place your latest PDF CV in the following directory:

```
public/cv/Adolphe_Uwayo_CV_2025.pdf
```

---

## 🛠️ Tech Stack

- ⚛️ [React](https://react.dev/)
- 🟦 [TypeScript](https://www.typescriptlang.org/)
- ⚡ [Vite](https://vitejs.dev/)
- 🎨 [Tailwind CSS](https://tailwindcss.com/)
- 🧩 [Lucide React Icons](https://lucide.dev/)

---

## 📁 Project Structure

```
src/
├── components/     # Reusable UI components (About, Projects, Skills, etc.)
├── App.tsx         # Root app layout
├── main.tsx        # Entry point
├── index.css       # Tailwind CSS configuration

public/
├── cv/             # CV (PDF format)
└── profile.jpg     # Profile image or banner
```

---

## 🤝 Contact Me

Feel free to reach out or connect:

- 📧 **Email:** [adolpheuwayo12@gmail.com](mailto:adolpheuwayo12@gmail.com)  
- 💻 **GitHub:** [@Adol1329](https://github.com/Adol1329)  
- 🔗 **LinkedIn:** [uwayo-adolphe-956b27373](https://www.linkedin.com/in/uwayo-adolphe-956b27373)  
- 🐦 **X (Twitter):** [@AdolpheUwayo](https://x.com/AdolpheUwayo)

---

> Designed and developed with passion and purpose by **Adolphe Uwayo** – 2025
